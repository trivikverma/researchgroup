Index of Multiple Deprivation (IMD) - 2010 - Local Authority District Geodata Pack: Liverpool (E08000012)


+ Abstract
This geodata pack provides the CDRC IMD for the year 2010 covering the Local Authority District: Liverpool (E08000012)


+ Contents
	 - readme.txt: Information about the CDRC Geodata pack
	 - metadata.xml: Metadata
	 - tables: Folder containing the csv files
	 - shapefiles: Folder containing the shapefiles


+ Citation and Copyright
The following attribution statements must be used to acknowledge copyright and source in use of these datasets:
Data provided by the ESRC Consumer Data Research Centre;2010;


+ Funding
Funded by: Economic and Social Research Council ES/L011840/1


+ Other Information
Areas that contained no information in the original dataset, are marked with NA in the csv files and NULL in the shapefiles.
